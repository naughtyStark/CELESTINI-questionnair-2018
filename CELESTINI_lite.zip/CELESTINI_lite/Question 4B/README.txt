The Video in which I demonstrate The RADAR AND the tap detection
(demonstrating both in the same video)
youtube link - https://youtu.be/7dLo0hY6_90

The video of me demonstrating the accuracy of the HCSR04 ultrasonic sensor(part ii) b) and c)) 
youtube link - https://youtu.be/LJj8kKQJL9Q

The CELESTINI_RADAR.py is common to both tap detection and RADAR 
Question 4B part i) has the .ino file for the RADAR action
Question 4B part iii) has the .ino file for the TAP detection action

