import serial
import matplotlib.pyplot as plt
plt.ion()
fig = plt.figure()

ser =  serial.Serial('COM3', 250000, timeout=0)

if ser.isOpen():
    ser.close()
ser.open()

X = 0
Y = 0

def input_reader():
    global X
    global Y
    while 1:
        try:
            X = int(ord(ser.read())<<8|ord(ser.read()))
            if(X>32767):
                X -= 65535
            
            Y = int(ord(ser.read())<<8|ord(ser.read()))
            if(Y>32767):
                Y -= 65535
            X /= 80
            Y /= 80
        except:
            break
    return X,Y

def main():
    plt.axis([-40,40,0,100])
    while(1):
        x,y = input_reader()
        plt.scatter(x,y)
        plt.show()
        plt.pause(0.0001)

main()
