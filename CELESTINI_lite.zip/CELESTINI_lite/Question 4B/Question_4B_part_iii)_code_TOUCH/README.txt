This folder contains the code for the touch detection part. 
The touch is detected by measuring the jerk(derivative of acceleration). if the jerk is above a certain threshold, it is taken as a tap/touch 
and the x,y, coordinates are relayed to the computer via serial communication.