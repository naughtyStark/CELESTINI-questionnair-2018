This README folder has been included as a formality,
The comments in the code explain the working pretty well.
However, here is a brief summary :

We start from either the top-right or the bottom left corner of the matrix.
going with the bottom left corner example here,
While The element is not found:
1)If the item to be searched is larger than the current element, we go fowards in the row(increment column index)
2)If the item to be searched is smaller than the current element, we go up in the column(decrease row index)
3)Repeat above process until we have stepped outside the matrix(column or row index out of bound). If this is the case then the element 
	does not exist
