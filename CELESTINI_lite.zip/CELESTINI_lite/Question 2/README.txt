This README file has been included as a formality. The logic for the code has been explained in the comments in the .cpp file itself
However , here is a brief summary :

Multiplication:
The code basically scans through the 2 matrices and remembers 2 things :
1)position of all non zero elements in each row of matrix A and each column of matrix B 
2)number of non zero elements in each row of matrix A and each column of matrix B 
a structure is used to store this information.

Once we have the information,
we run 2 outer loops for the N^2 elements,
1)before the inner most loop, we compare the number of non-zero elements in the row of A and the corresponding column of B and 
	the lesser of the 2 is the number of times the innermost loop will run.
2) Since we also know which one of them has lesser number
	of elements, we simply multiply the elements in the one which contains the least non zero elements with the corresponding elements in
	the other matrix
done

Convolution : 
The code again scans through the 2 matrices and remembers 2 things:
1)position of all non zero elements(stores their row and columns) in each matrix
2)number of non zero elements in each matrix

Once we have the information,
1) if matrix A has less number of elements than matrix B, then only the elements in B that correspond to the 
position of the non zero elements in A for that step are used for the convolution. 
2)If the number of elements in B is less than the number of elements in A, only the elements in B that are non 
zero are used for the convolution (the code makes it clearer as to what I am trying to say). 
	