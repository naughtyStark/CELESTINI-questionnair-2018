import pyvjoy

j = pyvjoy.VJoyDevice(1)

def controller(steer,throttle):
    
    j.data.wAxisX = 16384 + int(16384*steer)
    j.data.wAxisY = 16384 + int(16384*throttle)
    j.update()
