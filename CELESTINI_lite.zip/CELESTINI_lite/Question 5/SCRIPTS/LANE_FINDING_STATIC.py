import numpy as np
import cv2
from PIL import ImageGrab
'''
gives positive ROC in test3d when ROC should be negative,
we can probably solve this by changing the number of slices we take in the histogram thingaroo
probably something like if(np.sum(processed_img) > threshold) then we only need say 50 slices instead of 90 
'''


def ROC(curve):
    return ((1 + (2*curve[0]*710/2 + curve[1])**2)**1.5)/(2*curve[0])

def lane_curvature(left_line,right_line,weight_left,weight_right):
    deg = 2 #second order polynomial

    left_fit = np.polyfit(left_line[1],left_line[0],deg)
    
    x = [i*(3.7/440.) for i in left_line[0]]
    y = [i*(30/400.) for i in left_line[1]]  # real world values
    left_fit= np.polyfit(y,x,deg)
    
    right_fit = np.polyfit(right_line[1],right_line[0],deg)

    x = [i*(3.7/440.) for i in right_line[0]]
    y = [i*(30/400.) for i in right_line[1]]  # real world values
    right_fit= np.polyfit(y,x,deg)

    roc_right = ROC(right_fit)
    roc_left = ROC(left_fit)

    trust_right = 100*(weight_right)/(weight_left+weight_right)
    trust_left = 100*(weight_left)/(weight_left+weight_right)
    
    return 0.01*(trust_left*roc_left + trust_right*roc_right)
    
    

def find_lanes(img):
    #lists that contain orderwise coordinates of the points where the lane exists
    right_side_x = []
    right_side_y = []
    left_side_x = []
    left_side_y = []
    '''
    logic - take(~90) horizontal slices of the image and in each
    slice find the x coordinate of the white points, to do this, use a histogram
    in which the index of the histogram represents the position of the brightest
    pixel.
    for each slice there will be an x coordinate if there is a line
    if there is no line in the slice, the x coordinate will be 0,
    append the list with the values of the x coordinate
    to find the middle position of the lane,
    sum the x coordinate of each slice when x coordinate was not 0
    and then take the average(use counter to count the number of non zero
     x coordinates found) to find the average value of x
    the x coordinate of the new slice can not deviate by more than
    100 pixels(assumption), hence if there is a deviation larger than 100 pixels,
    it is probably noise
    update the lists in cycles when valid x's are found 
    '''
    #right side------------------------------
    last_x = 0
    right_mean_x =0
    weight_right = 0
    for i in reversed(range(10,100)): #reversed because the Y axis is inverted
        # columnwise sum of intensities
        '''
        slice height = 1% of image height and slice width is 1/2 of the image width
        '''
        hist = np.sum( img[ int(i*img.shape[0]/100) : int((i+1)*img.shape[0]/100), int(img.shape[1]/2):], axis=0)
        #argmax function returns the position of the index with max value
        x = int(np.argmax(hist)) + img.shape[1]/2 # adding offset as well
        y = int(i*img.shape[0]/100) #slice position
    
        #if it is not the first slice and there is a large deviation
        if (abs(x - last_x)>100 and not (i==99) and not (last_x==0)):
            pass #basically skip it, its not useful
        elif( x == img.shape[1]/2): # blank slice
            pass
        else:
            right_side_x.append(x)
            right_side_y.append(y)
            last_x = x
            right_mean_x += x
            weight_right += 1
    
    right_mean_x /= weight_right #find the mean position
    
    #left side ---------------------------------
    left_mean_x=0
    last_x=0
    weight_left=0
    for i in reversed(range(10,100)): #reversed because the Y axis is inverted
        # columnwise sum of intensities
        '''
        slice height = 1% of image height and slice width is 1/2 of the image width
        '''
        hist = np.sum( img[int(i*img.shape[0]/100) : int((i+1)*img.shape[0]/100), :int(img.shape[1]/2)], axis=0)
        #argmax function returns the position of the index with max value
        x = int(np.argmax(hist)) #no offset required 
        y = int(i*img.shape[0]/100) #slice position

        #if it is not the first slice and there is a large deviation
        if (abs(x - last_x)>100 and not (i==99) and not (last_x==0)):
            pass #it is noise
        elif( x == 0 ): # blank slice
            pass
        else:
            left_side_x.append(x)
            left_side_y.append(y)
            last_x = x
            left_mean_x += x
            weight_left += 1

    left_mean_x /= weight_left

    left_line = (left_side_x,left_side_y)
    right_line = (right_side_x,right_side_y)

    #construct a simpler line using the first and last points
    left_line = ( left_line[0][ 1: (len(left_line[0])-1 ) ], left_line[1][ 1:(len(left_line[1])-1 ) ] )
    right_line = ( right_line[0][ 1: (len(right_line[0])-1 ) ],right_line[1][ 1:(len(right_line[1])-1 ) ] )

    mid_pt = (right_mean_x + left_mean_x)/2
    #offset is a value between -1 and 1 
    offset = float(2*(mid_pt - (img.shape[1]/2) ))/img.shape[1] # positive offset means go right

    roc = lane_curvature(left_line,right_line,weight_left,weight_right)
    
    return left_line, right_line, offset, roc
    

def channel_Isolate(image,channel):
    ## Takes in only RBG images
    if (channel == 'R'):
        return image[:,:,0]
    
    elif (channel == 'H'):
        HSV = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        return HSV[:,:,0]
    
    elif (channel == 'S'):
        HSV = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        return HSV[:,:,1]
        
    elif (channel == 'V'):
        HSV = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        return HSV[:,:,2]
    else:
        pass
    
    
def threshold_Channel(channel,thresh):
    retval, binary = cv2.threshold(channel.astype('uint8'), thresh[0], thresh[1], cv2.THRESH_BINARY)
    return binary

def transform(img,img_size):
    src = np.float32([[-200,250],[200,170],[600,170],[1000,250]])
    dst = np.float32([[0,400],[0,0],[800,0],[800,400]])
    perspective = cv2.getPerspectiveTransform(src,dst)
    warped = cv2.warpPerspective(img,perspective,img_size)
    return warped
    
def roi(img,vertices):
    mask = np.zeros_like(img)
    cv2.fillPoly(mask,vertices,255)
    mask = cv2.bitwise_and(img,mask)
    return mask

def process_img(original_img):
    processed_img = original_img
    #thresholding red 
    red_threshed = threshold_Channel(channel_Isolate(processed_img,'R'),(220,255))
    #thresholding HSV 
    V_threshed = threshold_Channel(channel_Isolate(processed_img,'V'),(220,255))        

    #converting to hsv
    HSV = cv2.cvtColor(processed_img, cv2.COLOR_RGB2HSV)
    lower_yellow = np.array([20, 255, 255])
    upper_yellow = np.array([50, 255, 255])
    #find yellow
    yellow = cv2.inRange(HSV, lower_yellow, upper_yellow)
    #finding the 3 possible types of whites by hsv , hsl and rgb

    sensitivity_1 = 68 # default sensitivity to get an idea of how much the image wants to shoot up a school
    sensitivity_2 = 60

    white = cv2.inRange(HSV, np.array([0,0,255-sensitivity_1]), np.array([255,20,255]))
    #print(np.sum(white))

    if (np.sum(white) > 230000):
        sensitivity_1 = 0
        sensitivity_2 = 0
        
    
    white = cv2.inRange(HSV, np.array([0,0,255-sensitivity_1]), np.array([255,20,255]))
    
    HSL = cv2.cvtColor(processed_img, cv2.COLOR_RGB2HLS)
    white_2 = cv2.inRange(HSL, np.array([0,255-sensitivity_2,0]), np.array([255,255,sensitivity_2]))
    
    white_3 = cv2.inRange(processed_img, np.array([200,200,200]), np.array([255,255,255]))
    #processed img is the bitwise OR of all images
    
    processed_img = red_threshed | V_threshed | yellow | (white & white_2 & white_3)
    #get region of interest
    
    roi_vertices = np.array([[-200,250],[200,170],[600,170],[1000,250]])
    processed_img = roi(processed_img,[roi_vertices])
    cv2.imshow('window1',processed_img)
    #transform the image to fit 800x600
    processed_img = transform(processed_img,(800,400))

    left_line,right_line,offset,roc = 0,0,0,0#find_lanes(processed_img)
    
    
    return processed_img,left_line,right_line,offset,roc


def main():
    img = np.array(ImageGrab.grab(bbox=(0,40,1024,768)))
    img = cv2.resize(img,(800,400))
    img,left_lane,right_lane,offset,roc = process_img(img)
    print(offset)
    print(roc)
    
    cv2.imshow('window3',img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

main()
