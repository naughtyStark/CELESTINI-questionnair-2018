import serial
from HAL_write import controller
##import time

ser =  serial.Serial('COM3', 250000, timeout=0)

if ser.isOpen():
    ser.close()
ser.open()

steering = 1500
throttle = 1500

def input_reader():
    global steering
    global throttle
    while 1:
        try:
            steering = ord(ser.read())<<8|ord(ser.read())
            throttle = ord(ser.read())<<8|ord(ser.read())
            s = (steering - 1500)*0.002
            t = (throttle - 1500)*0.002
            controller(s,t)
        except:
            break
    return (throttle-1000)*0.001,(steering-1000)*0.001

##while 1:
##    t,s = input_reader()
##    print(t,s)
##    time.sleep(0.05)
