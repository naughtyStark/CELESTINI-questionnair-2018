import numpy as np 
from PIL import ImageGrab
import cv2
import time
from alexnet import alexnet 
from key_check import key_check,key_press
from HAL_write import controller

WIDTH = 160
HEIGHT = 60
LR = 0.0005
EPOCH = 8
MODEL_NAME ='SIDHARTH-{}-{}-{}-{}.model'.format(LR,'alexnet',EPOCH,'nissan_GTR')

model = alexnet(WIDTH,HEIGHT,LR)
model.load(MODEL_NAME)

for i in list(range(4))[::-1]:
    print(i+1)
    time.sleep(1)

##print('forwards')
##PressKey(W)
##time.sleep(3)
##ReleaseKey(W)

def main():
    lasts=0
    paused = False
    while(True):
        if not paused:
            img = np.array(ImageGrab.grab(bbox=(0,40,1024,768)))#take screenshot
            img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)#convert to GRAYSCALE(easier to process)
            road_map = img[580:640,90:170] #the road map is within this 80x60 bounding box
            #ret,road_map = cv2.threshold(road_map,200,255,cv2.THRESH_BINARY)
            img = cv2.resize(img,(80,60))#resize the original image to 80x60
            img = np.concatenate((img,road_map),axis=1)#put the map and the main image together
            
            prediction = model.predict([img.reshape(WIDTH,HEIGHT,1)])[0]#prediction is the 0th index output of the model output
##            moves = list(np.around(prediction))
            #print(prediction)

            f = prediction[0]
            b = prediction[1]
            l = prediction[2]
            r = prediction[3]

            t = (f-b)
            s = (r-l)#left is +ve
##            if(s>=0):
##                s = s**2
##            if(s<0):
##                s = -s**2
##            if(t>=0):
##                t = t**2
##            if(t<0):
##                t = -t**2
            
            if(lasts>s and s>0):
                
                s=0
            if(lasts<s and s<0):               
                
                s=0
            lasts = s
            if(t<0.5 and t>0):
                t+=0.2
            if(t>-0.5 and t<0):
                t-=0.2
##            if  s < 0.5:
##                print('left')
##            if  t > 0.5:
##                print('forwards')
##            if  s > 0:
##                print('right')
##            if  t < 0:
##                print('brake')

            controller(s,t)
            
        keys = key_press()
        if 'P' in keys:
            if paused:
                paused = False
                time.sleep(1)
            else:
                paused = True
                controller(0,0)
            
main()
