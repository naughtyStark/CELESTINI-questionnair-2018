The videos demonstrate the idea that we are proposing in pieces.

Question_5_Part_1 -> demo of the behavioural neural net playing the game(It generally drives a lot better but it was not driving that great 
during the recording for some reason)
youtube link - https://youtu.be/B-87ePlEG9E

Question_5_Part_1.5-> my first attempt at behaviour mapping during my internship at omnipresent robotics last year.
youtube link - https://youtu.be/dJcbwkCeyuU

Question_5_Part_2 -> demo of the lane detection and explanation
youtube link - https://youtu.be/gprXq2dZxL4

Question_5_Part_3 -> demo of the object detection (COCO)(Script not included because I didn't create it, I straight up copied it
from the internet so it's not my own work)
youtube link - https://youtu.be/GRtD7uLQNW4


THE SCRIPTS HAVE NOT BEEN INCLUDED FOR YOU TO RUN ON YOUR MACHINE BUT ONLY AS A PROOF OF WORK.(There are a lot of dependencies that I
have not included like PXYINPUT(import xbox) and a few other dependencies that I can't remember).

The SDC_STEP 4.py is the script to be executed for making the neural net control the car.
model_trainer_STEP_3.py is the script used to train the alexnet neural net.
data_balancer_STEP_2.py is the script used to balance the recorded data(equal number of left,right forwards and brake)
trainer_STEP_1.py is the script used to collect the training data(annotated data. the control inputs from the user
are taken as the labels for each image)
alexnet.py is the script which contains the model definition

LANE_FINDING_STATIC.py is the script to run the lane detection only once(for display purposes)
lane_finding.py is the script to run the lane detection continuously

